# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Contrato de captura de input (IInputProvider), abstraido por nome de acao data-driven."""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Tuple


class IInputProvider(ABC):
    """
    Contrato de captura de input. O nucleo/produtos so conhecem NOMES
    de acao (`str`), carregados de bindings JSON data-driven -- nunca
    codigos de tecla/botao especificos de um backend (nada de
    `pygame.K_SPACE` vazando para fora de `ouroboros.adapters`).
    """

    @abstractmethod
    def load_bindings(self, bindings_path: str) -> None:
        """Carrega o mapeamento acao -> tecla/botao fisico a partir de um arquivo JSON de bindings."""
        ...

    @abstractmethod
    def poll(self) -> None:
        """
        Consome a fila de eventos nativos do backend concreto e
        atualiza o ESTADO INTERNO (arrays/flags primitivos ja
        pre-alocados na implementacao concreta). Chamado no maximo uma
        vez por frame pelo laco principal; NAO retorna nem constroi
        nenhum objeto de snapshot novo -- as consultas de estado abaixo
        leem esse estado interno ja atualizado.
        """
        ...

    @abstractmethod
    def is_action_pressed(self, action_name: str) -> bool:
        """True no frame em que `action_name` transicionou de solto para pressionado."""
        ...

    @abstractmethod
    def is_action_held(self, action_name: str) -> bool:
        """True enquanto `action_name` permanece pressionado, independente de borda."""
        ...

    @abstractmethod
    def is_action_released(self, action_name: str) -> bool:
        """True no frame em que `action_name` transicionou de pressionado para solto."""
        ...

    @abstractmethod
    def get_axis(self, axis_name: str) -> float:
        """Valor continuo `[-1.0, 1.0]` de um eixo (analogico, D-pad, WASD combinado, etc.)."""
        ...

    @abstractmethod
    def get_cursor_position(self) -> Tuple[float, float]:
        """Posicao do cursor/mouse em PIXELS de tela (mesma convencao de
        `transform.position_x/y`/`IRenderer.get_viewport_size` -- nada
        normalizado 0..1 em lugar nenhum do motor), atualizada no
        MAXIMO uma vez por frame por `poll()` (mesmo contrato de
        `is_action_held`/`get_axis`: le estado ja cacheado, nunca
        consulta o backend concreto diretamente). Nao compensada por
        `set_camera_offset` (screen-shake desloca o que e DESENHADO,
        nao o que e testado -- mesmo criterio ja usado por
        `CollisionSystem`/`JudgmentSystem`, que tambem nunca compensam
        camera na logica de jogo)."""
        ...

    @abstractmethod
    def wants_quit(self) -> bool:
        """True se o backend recebeu um pedido nativo de encerramento da aplicacao."""
        ...

    def connected_pads(self) -> int:
        """Quantos controles fisicos estao conectados AGORA.

        Existe porque uma interface que promete a tecla errada e pior que uma
        que nao promete nada: quem esta com o controle na mao lendo "ESPACO
        pular" conclui que o controle nao funciona -- e ele funciona. Com
        este numero, o produto escolhe de que arranjo falar, e volta a falar
        de teclas quando o controle e desligado.

        Default: 0 (backends sem controle continuam validos, mesmo criterio
        de `set_rumble`).
        """
        return 0

    def get_mouse_delta(self) -> Tuple[float, float]:
        """Quanto o mouse andou desde o `poll()` anterior, em pixels (dx, dy) -- o que um
        jogo em primeira pessoa usa para olhar em volta (ROADMAP M21). Continua valendo com o
        cursor capturado (`set_mouse_captured`), quando a posicao do cursor fica parada.
        Default: (0, 0)."""
        return (0.0, 0.0)

    def set_mouse_captured(self, captured: bool) -> None:
        """Prende e esconde o cursor na janela (primeira pessoa) ou devolve. Default: no-op."""

    @abstractmethod
    def set_rumble(self, low_freq: float, high_freq: float, duration_sec: float) -> None:
        """Dispara vibracao (haptics/rumble) no controle fisico, se o
        backend/dispositivo suportar -- NUNCA levanta erro na ausencia de
        hardware compativel (controle desconectado, backend sem suporte a
        force feedback): vira um no-op silencioso, o mesmo criterio de
        `poll()` nao levantar erro sem dispositivo de audio.

        `low_freq`/`high_freq` sao intensidades `0.0..1.0` dos dois motores
        (grave/agudo, convencao padrao de controles modernos -- DualShock/
        Xbox); `duration_sec` e a duracao em segundos. Chamado no MAXIMO
        uma vez por evento de feedback (nunca em loop quente); nucleo/
        produtos nao sabem que existe um `pygame.joystick` por baixo (a
        mesma regra de abstracao de `is_action_held`)."""
        ...
