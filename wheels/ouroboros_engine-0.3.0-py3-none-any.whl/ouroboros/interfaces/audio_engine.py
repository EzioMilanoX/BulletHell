# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Contrato de reproducao de audio/efeitos sonoros (IAudioEngine)."""
from __future__ import annotations

from abc import ABC, abstractmethod

from ouroboros.interfaces.audio_clock import IAudioClock


class IAudioEngine(ABC):
    """
    Contrato de reproducao de audio/efeitos sonoros. Recebe apenas
    identificadores/caminhos e valores primitivos -- nunca objetos de
    jogo ou tipos de uma biblioteca de audio concreta.
    """

    @abstractmethod
    def load_track(self, track_id: str, file_path: str) -> None:
        """Carrega a faixa musical `file_path` sob o identificador `track_id`, fora do loop de gameplay."""
        ...

    @abstractmethod
    def play_track(self, track_id: str, start_offset_seconds: float = 0.0, loop: bool = False) -> None:
        """Inicia a reproducao de `track_id` e (re)inicializa o `IAudioClock` retornado por `get_clock()`."""
        ...

    @abstractmethod
    def stop_track(self, track_id: str) -> None:
        """Interrompe a reproducao de `track_id`, se estiver tocando."""
        ...

    @abstractmethod
    def pause_track(self, track_id: str) -> None:
        """Pausa a reproducao de `track_id` (se for a faixa atual) SEM resetar a
        posicao -- `get_clock().now_seconds()` congela no valor exato do momento
        da pausa ate `resume_track` (ROADMAP M2 -- pilha de cenas/pausa)."""
        ...

    @abstractmethod
    def resume_track(self, track_id: str) -> None:
        """Retoma `track_id` (se for a faixa atual e estiver pausada) exatamente de
        onde parou -- `get_clock().now_seconds()` volta a avancar a partir do valor
        congelado por `pause_track`, nunca de um reset."""
        ...

    @abstractmethod
    def load_sound(self, sound_id: str, file_path: str) -> None:
        """Pre-carrega e cacheia `file_path` como um efeito sonoro curto sob o
        nome `sound_id`, fora do loop de gameplay -- espelha `load_track`, mas
        para uma amostra ONE-SHOT (`play_one_shot`), nao uma faixa em stream.
        Da a uma amostra baseada em arquivo um nome amigavel, simetrico ao que
        `register_tone` ja permite para um som sintetizado."""
        ...

    @abstractmethod
    def play_one_shot(self, sound_id: str, volume: float = 1.0) -> None:
        """Dispara um efeito sonoro curto identificado por `sound_id`, sem afetar `get_clock()`."""
        ...

    def play_spatial(self, sound_id: str, volume: float = 1.0, pan: float = 0.0) -> None:
        """Como `play_one_shot`, com o som vindo de um lado: `pan` -1 (todo na esquerda) a
        1 (todo na direita) -- a pista de onde algo esta, sem precisar ver (ROADMAP M21).
        Default: ignora o `pan`."""
        self.play_one_shot(sound_id, volume)

    @abstractmethod
    def get_clock(self) -> IAudioClock:
        """Retorna o `IAudioClock` associado a faixa musical atualmente em reproducao."""
        ...

    # ------------------------------------------------------------------
    # Volume da faixa (ROADMAP M17): NAO-abstrato com default no-op, como
    # `register_tone` — backends existentes continuam validos. O volume dos
    # efeitos ja e por disparo (`play_one_shot(volume=...)`); a faixa em
    # stream nao tinha como baixar.
    # ------------------------------------------------------------------

    def set_track_volume(self, volume: float) -> None:
        """Volume da faixa musical, de 0.0 (mudo) a 1.0 (cheio); vale para a
        faixa atual e para as proximas `play_track`. Valores fora do intervalo
        sao limitados. Default: no-op."""

    # ------------------------------------------------------------------
    # SFX procedural (ROADMAP M4): metodo NAO-abstrato com default no-op —
    # permite jogos sem assets de audio sintetizarem efeitos curtos.
    # Chamado na composicao/cena (fora do loop de gameplay).
    # ------------------------------------------------------------------

    def register_tone(self, sound_id: str, kind: str = "square",
                      freq: float = 440.0, duration: float = 0.12) -> None:
        """Sintetiza e registra um efeito curto sob `sound_id`, tocavel
        depois via `play_one_shot`. `kind`: square | noise | sweep | zap.
        Default: no-op (backends sem suporte ignoram)."""
