# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""
Modulo NEUTRO -- a UNICA definicao compartilhada entre o escritor offline
e o leitor runtime de beatmap.json.

CRITICO: este modulo NUNCA importa librosa, nunca importa nada de
ouroboros.rhythm.offline.* e nunca importa pygame/godot. Isso e o que
garante que `ouroboros.rhythm.runtime.beatmap_loader` possa ser
importado no processo de jogo shippado SEM arrastar transitivamente a
dependencia pesada de librosa (e numba/scipy/soundfile) que o pipeline
offline usa. Tanto `ouroboros.rhythm.offline.beatmap_schema` quanto
`ouroboros.rhythm.runtime.beatmap_loader` importam
`BEATMAP_SCHEMA_VERSION` e os nomes de campo EXCLUSIVAMENTE deste
modulo -- nunca um do outro.
"""
from __future__ import annotations

from typing import Tuple

BEATMAP_SCHEMA_VERSION: int = 1
"""Versao do formato de `beatmap.json`. Incrementada a cada mudanca
incompativel de schema; `BeatmapLoader` (runtime) DEVE RECUSAR carregar
uma versao desconhecida em vez de tentar interpretar campos ausentes/
renomeados como se fossem a versao atual.
"""

REQUIRED_ROOT_FIELDS: Tuple[str, ...] = ("version", "track_id", "bpm", "threats")
"""Campos obrigatorios do documento raiz de `beatmap.json`."""

REQUIRED_THREAT_FIELDS: Tuple[str, ...] = ("timestamp_seconds", "threat_type", "lane", "strength")
"""Campos obrigatorios de cada entrada da lista `threats` do documento."""

OPTIONAL_THREAT_FIELDS: Tuple[str, ...] = ("layer",)
"""Campos OPCIONAIS de cada ameaca. `layer` (string, ex.: "kick"/"vocal")
identifica a CAMADA de extracao que gerou o evento nos Perfis de
Extracao multi-layer ("hybrid") -- o produto roteia por ela (ex.: kicks
nas extremidades, vocais no centro). Beatmaps antigos, sem o campo,
continuam validos: o schema permanece uniforme, apenas com uma
propriedade adicional."""

REQUIRED_OSU_HIT_OBJECT_FIELDS: Tuple[str, ...] = ("timestamp_seconds", "threat_type", "x", "y", "strength")
"""Campos obrigatorios de cada hit-object do modo Osu! (ROADMAP M15) --
schema PARALELO a `REQUIRED_THREAT_FIELDS` (nao uma extensao dela; o
documento raiz -- `version`/`track_id`/`bpm`/`threats`, ver
`REQUIRED_ROOT_FIELDS` -- e IDENTICO nos dois modos, so o formato de
CADA entrada de `threats` diverge)."""

OPTIONAL_OSU_HIT_OBJECT_FIELDS: Tuple[str, ...] = ("layer", "end_x", "end_y", "duration_seconds")
"""Campos OPCIONAIS de um hit-object Osu!. `end_x`/`end_y`/
`duration_seconds` sao obrigatorios NA PRATICA para um SLIDER (validado
por `OsuBeatmapLoader`/`OsuBeatmapValidator` contra o `threat_type`
resolvido, nao por uma tupla estatica de campos -- um CIRCLE nunca os
tem)."""
